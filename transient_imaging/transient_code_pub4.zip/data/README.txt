Acquired raw data are saved in 'data/rawdata'.
