1. Download the data package from the website of this paper
F. Heide, M. Hullin, J. Gregson, W. Heidrich. Low-budget Transient Imaging using Photonic Mixer Devices. SIGGRAPH 2013.
http://www.cs.ubc.ca/labs/imager/tr/2013/TransientPMD/

2. Copy the content in the 'data/images' in the package to this path.
