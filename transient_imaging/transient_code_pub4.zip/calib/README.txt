Calibrated correlation functions are in 'calib/cfs'.
