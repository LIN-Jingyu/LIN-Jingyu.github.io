Transient Image Reconstruction
==================================

Acquire
-------
Capture images. 'capture1' for test, 'capture5' for capture multi-frequency and multi-phase data.


real_scenes
-----------
Reconstruct transient images from captured data.


transient_ubc
-------------
Reconstruct transient images from UBC data.

Download the data package from the website of this paper and put in the 'data' path:
F. Heide, M. Hullin, J. Gregson, W. Heidrich. Low-budget Transient Imaging using Photonic Mixer Devices. SIGGRAPH 2013.

Run 'rec_ubcdata'.



calib
-----
parameters of calibrated correlation function



TOF_tools
---------
Hardware interface. Invoked by commands in Acquire.


functions
---------
supporting functions


