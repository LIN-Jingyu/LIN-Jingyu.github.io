% check data
addpath('..\functions')

%% read data
rawpath = '..\Acquire';
sel_data = '52524';
outputpath = sprintf('%s\\rawdata\\scene_%s',rawpath,sel_data);
dataname = 'meas_data_take000.dat';
fn = sprintf('%s\\%s',outputpath,dataname);
phs_len = 10;
freq_len = 161;
shuttersz = 3;
sel_sh = shuttersz;
h = 120; w = 165;
fprintf('reading %s ...\n',outputpath);
dat = ReadDump_Shutter(fn,phs_len,freq_len,shuttersz,h,w,sel_sh);
% w, h, 2, freq_len, phs_len

%% plots
x = 80; y = 60;
d = permute( dat(x,y,1,5:15,:), [5 4 3 2 1]);
figure(1); plot(d); legend('1','2','3','4','5','6')
